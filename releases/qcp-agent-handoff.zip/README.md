# QCP Arena agent handoff

Start with qcp-handoff/START_HERE.md.
